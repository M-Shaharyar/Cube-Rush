using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField] private float movementSpeed;
    [SerializeField] private float _minSpeed;
    [SerializeField] private float _maxSpeed;
    [SerializeField] private Vector3 _startingPosition;
    [SerializeField] private float _minXAxis;
    [SerializeField] private float _maxYAxis;
    [SerializeField] private GameObject _gameObjectText; 
    private const float _roatateSpeed = 30f;
    private void Start() {
        _startingPosition = this.transform.position;
    }
    void Update()
    {
        MoveEnemy();
    }
    private void MoveEnemy(){
        transform.position += Vector3.left * movementSpeed * Time.deltaTime;
        transform.Rotate(Vector3.up * _roatateSpeed *Time.deltaTime);
    }
    private void OnTriggerEnter(Collider other) {
        if(other.name == "Portal"){
            float RandomXAxis = Random.Range(_minXAxis,_maxYAxis);
            _startingPosition.z = RandomXAxis;
            this.transform.position = _startingPosition; 
            movementSpeed = Random.Range(_minSpeed,_maxSpeed);
        }
        else if(other.name == "Player"){
            _gameObjectText.SetActive(true);
            Time.timeScale = 0;
        }
        
    }
}
