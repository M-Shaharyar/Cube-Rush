using NUnit.Framework;
using UnityEngine;

public class Bouns : MonoBehaviour
{
    [SerializeField] private float _moveSpeed = 2f;
    [SerializeField] Vector3 startingPosition;
    [SerializeField] private float minX,maxX;
    [SerializeField] private Portal portal;
    void Start()
    {
        startingPosition = this.transform.position;
    }

    void Update()
    {
        Move(Vector3.left*_moveSpeed*Time.deltaTime);
    }

    private void Move(Vector3 movementVector)
    {
        this.transform.position += movementVector;
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.name == "Portal" || other.name == "Player"){
            
            if(other.name == "Player"){
                if(portal!=null){
                    portal.AddScore(5);
                }
            }
            float RandomXAxis = Random.Range(minX,maxX);
            startingPosition.z = RandomXAxis;
            this.transform.position = startingPosition;
        }
    }
}
