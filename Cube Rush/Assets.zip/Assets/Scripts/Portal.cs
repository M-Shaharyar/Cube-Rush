using UnityEngine;
using TMPro;
using System;
using System.Threading;

public class Portal : MonoBehaviour
{
    [SerializeField] private int _score = 0;
    [SerializeField] private TextMeshProUGUI _scoreText;
    [SerializeField] private float _gameDuration = 60f;
    [SerializeField] private float timer;
    [SerializeField] private TextMeshProUGUI timerText;
    void Start()
    {
        timer = _gameDuration;
    }
    private float gameTime = 0f;
    void Update()
    {
        if (timer > 0 ){
            timer -= Time.deltaTime;
            UpdateTimerUI();
        }
        else{
            EndGame();
        } 
    }
    private void UpdateTimerUI(){
        timerText.text = "Timer:"+ Mathf.Ceil(timer).ToString()+"s";
    }
    private void EndGame(){
        Time.timeScale = 0;
    }
   public void AddScore(int amount){
    _score += amount;
     _scoreText.text = "Score : " + _score;
   }
}
