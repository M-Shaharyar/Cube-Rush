using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField] private float _moveSpeed = 3f;
    void Update()
    {
        if(Input.GetKey(KeyCode.RightArrow)){
            Move(new Vector3(0,0,-_moveSpeed*Time.deltaTime));
        }
        else if(Input.GetKey(KeyCode.LeftArrow)){
            Move(new Vector3(0,0,_moveSpeed*Time.deltaTime));
        }
    }
    private void Move(Vector3 movementVector){
        this.transform.position += movementVector;
    }
}
